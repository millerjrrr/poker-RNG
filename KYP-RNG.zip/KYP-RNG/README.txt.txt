KYP RNG App
--------------
- Click the colored number to generate a number (0-99)
- Double-click the logo button to spawn a new window
- Close the window with the ✕ button or Esc

This is a standalone executable; no installation required.
